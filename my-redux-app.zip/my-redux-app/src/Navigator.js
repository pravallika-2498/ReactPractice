import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Redirect, Switch } from 'react-router-dom';
import Login from './Components/Login';
import Register from './Components/Register';
import Confirmation from './Components/Confirmation';
import UserDetails from './Components/UserDetails';

export const getStore = (name) => {
    if (!name) return
    return JSON.parse(window.localStorage.getItem(name))
  }

function AuthenticatedRoute ({component: Component, ...rest}) {
  return (
    <Route
      {...rest}
      render={(props) => getStore('user') ? <Component {...props} />
        : <Redirect to={{pathname: '/login', state: {from: props.location}}} />}
    />
  )
}
class Navigator extends Component {
    render() {
      return (
       <Router>
            <Switch>
              <Route exact path="/login" component={Login} />
              <Route exact path="/register" component={Register} />
              <Route exact path="/confirmation" component={Confirmation} />
              <AuthenticatedRoute exact path='/userdetails' component={UserDetails} />
              <Route path='*' component={Login} />
            </Switch>
          </Router>
      )
    }
  }
  
  export default Navigator;