import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from 'react-redux';
import { ActionCreators } from '../../Store/Actions';

export class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emailid: '',
      password: '',
      errors: {
        emailid: 'Enter User id!',
        password: 'Enter Password!'
      },
      loginStatus: '',
      submitted: false
    }
  }

  inputChange = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });
    this.validationErrorMessage(event);
  }

  // getStore = (name) => {
  //   if (!name) return
  //   return JSON.parse(window.localStorage.getItem(name))
  // }


  validationErrorMessage = (event) => {
    const { name, value } = event.target;
    let errors = this.state.errors;
    switch (name) {
      case 'emailid':
        errors.emailid = value.length < 1 ? 'Enter User Name' : '';
        break;
      case 'password':
        errors.password = value.length < 1 ? 'Enter Password' : '';
        break;
      default:
        break;
    }
    this.setState({ errors :errors});
  }

  validateForm = (errors) => {
    let valid = true;
    console.log(errors)
    Object.entries(errors).forEach(item => {
      console.log(item)
      item && item[1].length > 0 && (valid = false)
    })
    console.log(valid)
    return valid;
  }

  loginForm = (event) => {
    this.setState({ submitted: true });
    event.preventDefault();
    let pass = false;
    if (this.validateForm(this.state.errors)) {
      console.info('Valid Form')
      const users = JSON.parse(window.localStorage.getItem("users"));
      if (users) {
        users.map(ele => {
          if (ele.emailid === this.state.emailid && ele.password === this.state.password) {
            pass = true;
            this.props.dispatch(ActionCreators.login(ele));
            return pass;
          } else {
            this.setState({ loginStatus: 'Login Failed! Invalid Username and Password' });
          }
        });
        if (pass) {
          this.props.history.push('/displaydetails');
        }
      }
      else {
        this.setState({ loginStatus: 'Login Failed! Invalid Username and Password' })
      }
    }

    else {
      console.log('Invalid Form')
    }
  }

  render() {
    const { emailid, password, errors, submitted, loginStatus } = this.state;
    return (
      <div >
        <label htmlFor="username" >User Name:</label>
        <input type="text" value={emailid} name="emailid" onChange={(e) => { this.inputChange(e) }}  id="username" placeholder="User Name" /><br />
        {submitted && errors.emailid.length > 0 && <span >{errors.emailid}</span>}<br />
        <label htmlFor="password" >Password:</label>
        <input type="password" value={password} autoComplete="on" name="password" onChange={(e) => { this.inputChange(e) }}  id="password" placeholder="Password" /><br />
        {submitted && errors.password.length > 0 && <span >{errors.password}</span>}<br />
        {submitted && loginStatus.length > 0 && <span >{loginStatus}</span>}<br />
        <button type="submit"  onClick={this.loginForm}>Login</button>
        <a href="/register">Register</a>
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    profile: state.user.profile
  }
}

export default connect(mapStateToProps)(withRouter(Login));
