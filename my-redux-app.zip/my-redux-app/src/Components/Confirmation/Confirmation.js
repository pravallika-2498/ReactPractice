import React, { Component } from 'react';
import { withRouter } from "react-router-dom";

export class Confirmation extends Component {

    render() {
        return (
            <div >
                <h1>Registration successful!</h1>
                <div>
                    Please login here : <a href="/login">Login</a>

                </div>
            </div>
        )
    }
}


export default (withRouter(Confirmation));
