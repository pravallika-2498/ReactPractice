import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from "react-router-dom";

let users =[];
export class Confirmation extends Component {
    componentDidMount() {
        if (this.props.profile.UserName !== "") {
          users.push(this.props.profile);
          const userlist = JSON.parse(window.localStorage.getItem("users"));
          if(userlist)
          {
           users = [...users, ...userlist];
          }
          window.localStorage.setItem('users', JSON.stringify(users));
        }
      }
    render() {
        return (
            <div >
                <h1>Registration successful!</h1>
                <div>
                    Please login here : <a href="/login">Login</a>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        profile: state.user.profile
    }
}

export default connect(mapStateToProps)(withRouter(Confirmation));
