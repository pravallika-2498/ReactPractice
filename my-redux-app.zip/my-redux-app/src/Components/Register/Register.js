import React, { Component } from 'react';


export class Register extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: {
                UserName: "",
                password: "",
                age: "",
                emailid: "",
                phone: ""
            },
            submitted: false,
            errors: {
                user: {
                    UserName: 'Enter UserName',
                    phone: 'Invalid Number',
                    emailid: 'Email is not valid!',
                    age: "Enter age",
                    password: "Enter password"
                }
            },
        }
    }
    isValidEmail = (value) => {
        return !(value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,64}$/i.test(value))
    }
    formatPhoneNumber = (value) => {
        if (!value) return
        const currentValue = value.replace(/[^\d]/g, '');
        const mobileNoLength = currentValue.length;
        if (mobileNoLength >= 7) {
            if (mobileNoLength < 4) return currentValue;
            if (mobileNoLength < 7) return `(${currentValue.slice(0, 3)}) ${currentValue.slice(3)}`;
            return `(${currentValue.slice(0, 3)}) ${currentValue.slice(3, 6)}-${currentValue.slice(6, 10)}`;
        } else {
            return currentValue;
        }
    }
    inputChange = (event) => {
        let telphone = ''
        const { name, value } = event.target;
        const user = this.state.user;
        if (name === 'telephone') {
            telphone = this.formatPhoneNumber(value);
            user[name] = telphone;
        } else {
            user[name] = value;
        }
        this.setState({ user });
        this.validationErrorMessage(event);
    }
    validationErrorMessage = (event) => {
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'UserName':
                errors.user.UserName = value.length < 1 ? 'Enter First Name' : '';
                break;
            case 'emailid':
                errors.user.emailid = this.isValidEmail(value) ? '' : 'Email is not valid!';
                break;
            case 'phone':
                errors.user.phone = value.length < 1 && value.length > 10 ? 'Enter valid telephone number' : '';
                break;
            case 'age':
                errors.user.age = value.length < 1 ? 'enter age' : '';
                break;
            case 'password':
                errors.user.password = value.length < 1 ? 'enter password' : '';
                break;
            default:
                break;
        }

        this.setState({ errors });
    }
    validateForm = (errors) => {
        let valid = true;
        Object.entries(errors.user).forEach(item => {
            console.log(item)
            item && item[1].length > 0 && (valid = false)
        })
        return valid;
    }
    submitForm = async (event) => {
        this.setState({ submitted: true });
        event.preventDefault();
        if (this.validateForm(this.state.errors)) {
            console.info('Valid Form')
            window.localStorage.setItem("user", JSON.stringify(this.state.user));
            this.props.history.push('/confirmation')
        } else {
            console.log('Invalid Form')
        }
    }
    render() {
        const { UserName, password, age, emailid, phone } = this.state.user;
        const { submitted } = this.state;
        return (
            <React.Fragment>
                <h1>Register Page</h1>
                <label className="col-sm-2 col-form-label">Name</label>
                <input type="text" value={UserName} name="UserName" onChange={(e) => { this.inputChange(e) }} placeholder="Enter Name" />
                {submitted && this.state.errors.user.UserName.length > 0 && <span className='error'>{this.state.errors.user.UserName}</span>}<br />
                <label className="col-sm-2 col-form-label">Password</label>
                <input type="password" value={password} name="password" onChange={(e) => { this.inputChange(e) }} placeholder="Enter password" />
                {submitted && this.state.errors.user.password.length > 0 && <span className='error'>{this.state.errors.user.password}</span>}<br />
                <label className="col-sm-2 col-form-label">Age</label>
                <input type="text" value={age} name="age" onChange={(e) => { this.inputChange(e) }} placeholder="Enter Age" />
                {submitted && this.state.errors.user.age.length > 0 && <span className='error'>{this.state.errors.user.age}</span>}<br />
                <label className="col-sm-2 col-form-label">Email</label>
                <input type="text" value={emailid} name="emailid" onChange={(e) => { this.inputChange(e) }} placeholder="Enter email id" />
                {submitted && this.state.errors.user.emailid.length > 0 && <span className='error'>{this.state.errors.user.emailid}</span>}<br />
                <label className="col-sm-2 col-form-label">Phone Number</label>
                <input type="text" value={phone} name="phone" onChange={(e) => { this.inputChange(e) }} placeholder="Enter phone number" />
                {submitted && this.state.errors.user.phone.length > 0 && <span className='error'>{this.state.errors.user.phone}</span>}<br />
                <button type="button" className="button" onClick={this.submitForm}>Submit</button>
            </React.Fragment>
        );
    }
}

export default Register;