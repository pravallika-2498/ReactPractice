import UpdateDetails from './UpdateDetails';

export default UpdateDetails;
