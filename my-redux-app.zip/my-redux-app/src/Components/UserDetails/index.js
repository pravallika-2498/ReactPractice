import UserDetails from './UserDetails';

export default UserDetails;
