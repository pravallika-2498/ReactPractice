import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from 'react-redux';
import { ActionCreators } from '../../Store/Actions';

export class UserDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {
        UserName: "",
        password: "",
        age: "",
        emailid: "",
        phone: ""
      }
    }
  }
  componentDidMount() {
    const user = JSON.parse(window.localStorage.getItem("user"));
    this.setState({ user: user });
  }

  inputChange = (event) => {
    const { name, value } = event.target;
    const user = this.state.user;
    user[name] = value;
    this.setState({ user });
  }

  updateUser = ()=>{
   // this.props.dispatch(ActionCreators.updateProfile(this.state.user));
  }

  render() {
    return (
      <div >
        <h1>Display User Details</h1>
        <div>
          Name: <input type="text" name="UserName" onChange={(e) => { this.inputChange(e) }} value={this.state.user.UserName} /> <br />
          Password: <input type="text" name="password" onChange={(e) => { this.inputChange(e) }} value={this.state.user.password} /> <br />
          Age: <input type="text" name="age" onChange={(e) => { this.inputChange(e) }} value={this.state.user.age} /> <br />
          Email: <input type="text" name="emailid" onChange={(e) => { this.inputChange(e) }} value={this.state.user.emailid} /> <br />
          Phone: <input type="text" name="phone" onChange={(e) => { this.inputChange(e) }} value={this.state.user.phone} /> <br />
          <button type="submit" onClick={this.updateUser()}>Update</button>
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    profile: state.user
  }
}

export default connect(mapStateToProps)(withRouter(UserDetails));
