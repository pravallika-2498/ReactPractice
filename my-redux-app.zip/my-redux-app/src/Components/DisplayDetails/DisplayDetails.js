import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from 'react-redux';
import { ActionCreators } from '../../Store/Actions';
import { UpdateDetails } from '../UpdateDetails/UpdateDetails';

export class DisplayDetails extends Component {
    constructor(props) {
        super(props);

    }
  
    updateUser = () => {
       // this.props.dispatch(ActionCreators.updateDetailsStatus(true));
        this.props.history.push("/updatedetails");
    }
    render() {
        return (
             
            <div >
                <h1>Display User Details</h1>
                <div>
                    Name: {this.props.profile.UserName} <br />
                    Password: {this.props.profile.password}  <br />
                   { this.props.profile.age !== "" ? <React.Fragment> Age: {this.props.profile.age} <br /></React.Fragment> : "" }
                    Email: {this.props.profile.emailid} <br />
                    { this.props.profile.phone !== "" ? <React.Fragment>  Phone: {this.props.profile.phone} <br /> </React.Fragment>: ""} 
                    <button type="submit" onClick={this.updateUser}>Update</button>
                </div>
            </div>

        )
    }
}

const mapStateToProps = (state) => {
    return {
        profile: state.user.profile
    }
}

export default connect(mapStateToProps)(withRouter(DisplayDetails));
