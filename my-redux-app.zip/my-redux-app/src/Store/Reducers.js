const initialState = {
  profile: {
    UserName: '',
    phone: '',
    age: 28,
    emailid: '',
    password: ''
  },
  formSubmitted: false
}

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case "LOGIN":
    console.log('login', action.payload.user)
      return {
        ...state,
        profile: action.payload.user,
        formSubmitted: false 
      }
    case "ADD_USER":
      return {
        ...state,
        profile: action.payload.user,
        formSubmitted: false 
      }
    case "UPDATE_USER":
      return {
        ...state,
        profile: action.payload.user,
        formSubmitted: false 
      }
    case "FORM_SUBMITION_STATUS":
      return {
        ...state,
        formSubmitted: action.payload.status
      }
    default:    
      return state;
  }
}

export default reducer;