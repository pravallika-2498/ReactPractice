import React from 'react';
import Navigator from './Navigator';

class App extends React.Component {
  render() {
    return (
      <div>
        <Navigator />
      </div>
    )
  }
}

export default (App);
