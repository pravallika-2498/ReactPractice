
import React from 'react';
import './Register.css';
import Success from './Success';

class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = { name: "", mobile: "", isNameError: false, isMobileError: false, allclear: "" };
    }
    onNameChange = (event) => {
        this.setState({ name: event.target.value });
        if (this.state.name !== "") {
            this.setState({ isNameError: false });
            this.setState({ allclear: false });
        }
    }

    onMobileChange = (event) => {
        this.setState({ mobile: event.target.value });
        if (this.state.mobile !== "") {
            this.setState({ isMobileError: false });
            this.setState({ allclear: false });
        }
    }
    validateInputs = () => {
        if (this.state.name === "") {
            this.setState({ isNameError: true });
            this.setState({ allclear: false });
        }
        if (this.state.mobile === "") {
            this.setState({ isMobileError: true });
            this.setState({ allclear: false });
        }
        else {
            this.setState({ allclear: true });
        }
    }
    render() {

        return this.state.allclear ? <Success /> : (<div>
            <h1>Registration Form</h1>
            <p>Please fill the required Fields</p>
            <label>Name</label>
            <input type="text" className={this.state.isNameError ? "red-clr" : ""} value={this.state.name} onChange={this.onNameChange} />
            {this.state.isNameError ?
                <span className="txt-red">Please enter name!</span>
                : ""}
            <label> Mobile </label>
            <input type="text" className={this.state.isMobileError ? "red-clr" : ""} value={this.state.mobile} onChange={this.onMobileChange} />
            {this.state.isMobileError ?
                <span className="txt-red">Please enter valid  mobile number!</span>
                : ""}
            <button id="btn" onClick={() => { this.validateInputs() }}>Submit</button>

        </div>)

    }
}

export default Register;