// import logo from './logo.svg';
import './App.css';
import Register from './Register';

function App() {
return <div>
  <Register/>
</div> ;

}

export default App;
