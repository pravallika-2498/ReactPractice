import React from 'react';

class Success extends React.Component{

    render(){
        return <div>Success</div>

    }
}
export default Success;
